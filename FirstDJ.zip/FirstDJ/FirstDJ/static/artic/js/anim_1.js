VANTA.HALO({
            el: "#animat_1",
            mouseControls: true,
            touchControls: true,
            gyroControls: false,
            minHeight: 200.00,
            minWidth: 500.00,
            baseColor: 0x142857,
            backgroundColor: 0x242634,
            amplitudeFactor: 1.50,
            xOffset: -0.03,
            yOffset: 0.30,
            size: 1.10
            })